﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;


namespace AircraftBattle
{
    class Bullet
    {
        public Point pos;

        public Bullet(Point point)
        {
            // 开始等于导弹位置
            this.pos = point;
        }

        public bool isTarget(Point point)
        {
            int x = Math.Abs(point.X - pos.X);
            int y = Math.Abs(point.Y - pos.Y);
            if (x < 30 && y < 10)
            {
                return true;
            }
            return false;
        }

    }
}
