﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace AircraftBattle
{
    public partial class Form1 : Form
    {
        private Point plane_pos;
        private Point bullet_pos;
        private Point relative_pos;     // 相对位移

        private Thread plane_thread;
        private Thread bullet_thread;

        private delegate void MoveDele(Point point);
        private MoveDele planeDelegate;
        private MoveDele bulletDelegate;

        private int number;

        public Form1()
        {
            relative_pos = new Point(0, 0);
            bullet_pos = new Point();
            plane_pos = new Point();
            planeDelegate = new MoveDele(movePlane);    //处理飞机移动
            bulletDelegate = new MoveDele(moveBullet);
            InitializeComponent();
        }

        // 初始化飞机、导弹位置
        private void Form1_Load(object sender, EventArgs e)
        {
            plane_pos = plane_pb.Location;
            bullet_pos = bullet_pb.Location;
        }

        // 将飞机图片移到对应位置
        private void movePlane(Point pos)
        {
            plane_pb.Location = pos;
        }

        private void moveBullet(Point pos)
        {
            bullet_pb.Location = pos;
        }

        // 飞机移动
        private void RunPlane()
        {
            // 没被撞
            while (!isTarget())
            {
                Thread.Sleep(25);
                Point pos = plane_pb.Location;
                pos.X -= 5;
                if (pos.X < 0)
                {
                    pos.X = 450;
                }
                plane_pb.Invoke(planeDelegate, pos);
            }
            // 被撞了，飞机掉落
            Point hitPos = plane_pb.Location;
            while (hitPos.Y < 500 || hitPos.X > -20)
            {
                Thread.Sleep(5);
                hitPos.Y += 5;
                hitPos.X -= 5;
                plane_pb.Invoke(planeDelegate, hitPos);
            }
            MessageBox.Show("撞到飞机了，游戏结束！");
        }

        // 导弹移动
        private void RunBullet()
        {
            while (!isTarget())
            {
                Thread.Sleep(5);
                Point pos = bullet_pb.Location;
                pos.X += relative_pos.X;
                pos.Y += relative_pos.Y;
                // 不能超过边框
                if (pos.X < -20) pos.X = -20;
                if (pos.X > 385) pos.X = 385;
                if (pos.Y < 0) pos.Y = 0;
                if (pos.Y > 350) pos.Y = 350;
                bullet_pb.Invoke(bulletDelegate, pos);
            }
        }


        // 判断是否命中
        private bool isTarget()
        {
            Point ppos = plane_pb.Location;
            Point bpos = bullet_pb.Location;
            int x = Math.Abs(ppos.X - bpos.X);
            int y = Math.Abs(ppos.Y - bpos.Y);
            if(x<45&&y<10)
            {
                return true;
            }
            return false;
        }

        // 开始游戏
        private void button1_Click(object sender, EventArgs e)
        {
            if(plane_thread!=null && bullet_thread != null && plane_thread.IsAlive && bullet_thread.IsAlive)
            {
                MessageBox.Show("正在进行游戏！");
                return;
            }

            plane_thread = new Thread(new ThreadStart(RunPlane));
            bullet_thread = new Thread(new ThreadStart(RunBullet));

            plane_thread.Start();
            bullet_thread.Start();
            plane_pb.Location = plane_pos;
            bullet_pb.Location = bullet_pos;

        }

        // 重新开始游戏
        private void button2_Click(object sender, EventArgs e)
        {
            plane_thread.Abort();
            bullet_thread.Abort();
            plane_pb.Invoke(planeDelegate, plane_pos);
            bullet_pb.Invoke(bulletDelegate, bullet_pos);
        }

        // 上下左右操作
        private void button3_Click(object sender, EventArgs e)
        {
            relative_pos.Y = -5;
            relative_pos.X = 0;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            relative_pos.Y = 5;
            relative_pos.X = 0;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            relative_pos.Y = 0;
            relative_pos.X = -5;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            relative_pos.Y = 0;
            relative_pos.X = 5;
        }

   

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Environment.Exit(0);
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {

            switch (e.KeyCode)
            {
                case Keys.W:
                case Keys.Up:
                    button3_Click(sender, null);
                    break;

                case Keys.S:
                case Keys.Down:
                    button4_Click(sender, null);
                    break;

                case Keys.A:
                case Keys.Left:
                    button5_Click(sender, null);
                    break;

                case Keys.D:
                case Keys.Right:
                    button6_Click(sender, null);
                    break;
            }
        }
    }
}
