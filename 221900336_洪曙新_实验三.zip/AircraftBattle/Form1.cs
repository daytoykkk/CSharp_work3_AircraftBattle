﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace AircraftBattle
{
    public partial class AircraftBattle : Form
    {
        private Point plane_pos;
        private Point gun_pos;

        private Thread plane_thread;
        private Thread bullet_thread;
        private bool isBoom;

        private delegate void MoveDele(Point point);
        private MoveDele planeDelegate;
        private MoveDele gunDelegate;

        private Graphics gc;
        private List<Bullet> bullets;

        public AircraftBattle()
        {
            gun_pos = new Point();
            plane_pos = new Point();
            planeDelegate = new MoveDele(movePlane);    //处理飞机移动
            gunDelegate = new MoveDele(moveGun);
            this.isBoom = false;

            bullets = new List<Bullet>(0);
            panel1 = new MyPanel();

            InitializeComponent();
        }

        // 初始化飞机、导弹位置
        private void Form1_Load(object sender, EventArgs e)
        {
            gc = panel1.CreateGraphics();

            plane_pos = plane_pb.Location;
            gun_pos = gun_pb.Location;

            panel1.Paint += new PaintEventHandler(bullet_paint);
        }

        // 将飞机图片移到对应位置
        private void movePlane(Point pos)
        {
            plane_pb.Location = pos;
        }

        private void moveGun(Point pos)
        {
            gun_pb.Location = pos;
        }

        // 子弹移动
        private void moveBullets()
        {
            for(int i = 0; i < bullets.Count; i++)
            {
                bullets[i].pos.Y -= 5;
                if (bullets[i].pos.Y < 5)
                {
                    bullets.Remove(bullets[i]);
                    i--;
                    continue;
                }
                if (bullets[i].isTarget(plane_pb.Location))
                {
                    this.isBoom = true;
                }
            }
        }

        // 画子弹
        public void bullet_paint(Object sender, EventArgs e)
        {
            for(int i = 0; i < bullets.Count; i++)
            {
                if (bullets[i] != null)
                {
                    gc.FillEllipse(Brushes.Red, bullets[i].pos.X, bullets[i].pos.Y, 10, 10);
                }
            }
        }

        // 飞机移动
        private void RunPlane()
        {
            // 没被撞
            while (!isBoom)
            {
                Thread.Sleep(25);
                Point pos = plane_pb.Location;
                pos.X -= 5;
                if (pos.X < 0)
                {
                    pos.X = 450;
                }
                plane_pb.Invoke(planeDelegate, pos);
            }
            // 被撞了，飞机掉落
            Point hitPos = plane_pb.Location;
            while (hitPos.Y < 500 || hitPos.X > -20)
            {
                Thread.Sleep(5);
                hitPos.Y += 5;
                hitPos.X -= 5;
                plane_pb.Invoke(planeDelegate, hitPos);
            }
            MessageBox.Show("撞到飞机了，游戏结束！");
        }

        // 子弹移动
        private void RunBullet()
        {
            while (true)
            {
                moveBullets();
                Thread.Sleep(10);
                panel1.Invalidate();
            }
        }



        // 开始游戏
        private void button1_Click(object sender, EventArgs e)
        {
            if(plane_thread!=null && bullet_thread != null && plane_thread.IsAlive && bullet_thread.IsAlive)
            {
                MessageBox.Show("正在进行游戏！");
                return;
            }

            plane_thread = new Thread(new ThreadStart(RunPlane));
            bullet_thread = new Thread(new ThreadStart(RunBullet));

            plane_thread.Start();
            bullet_thread.Start();
            plane_pb.Location = plane_pos;
            gun_pb.Location = gun_pos;

        }

        // 重新开始游戏
        private void button2_Click(object sender, EventArgs e)
        {
            this.isBoom = false;
            plane_thread.Abort();
            bullet_thread.Abort();
            bullets.Clear();
            plane_pb.Invoke(planeDelegate, plane_pos);
            gun_pb.Invoke(gunDelegate, gun_pos);
        }

        // 上下左右操作
        private void button3_Click(object sender, EventArgs e)
        {
            Point pos = gun_pb.Location;
            pos.Y -= 5;
            gun_pb.Invoke(gunDelegate, pos);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Point pos = gun_pb.Location;
            pos.Y += 5;
            gun_pb.Invoke(gunDelegate, pos);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Point pos = gun_pb.Location;
            pos.X -= 5;
            gun_pb.Invoke(gunDelegate, pos);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Point pos = gun_pb.Location;
            pos.X += 5;
            gun_pb.Invoke(gunDelegate, pos);
        }

   

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Environment.Exit(0);
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {

            switch (e.KeyCode)
            {
                case Keys.W:
                case Keys.Up:
                    button3_Click(sender, null);
                    break;

                case Keys.S:
                case Keys.Down:
                    button4_Click(sender, null);
                    break;

                case Keys.A:
                case Keys.Left:
                    button5_Click(sender, null);
                    break;

                case Keys.D:
                case Keys.Right:
                    button6_Click(sender, null);
                    break;

                case Keys.Space:
                    e.Handled = true;
                    button7_Click(sender, null);
                    break;
            }
        }

        //发射子弹
        private void button7_Click(object sender, EventArgs e)
        {
            if (isBoom) return;
            Point pos = gun_pb.Location;
            Bullet bullet = new Bullet(new Point(pos.X + gun_pb.Size.Width / 2, pos.Y));
            bullets.Add(bullet);
        }
    }
}
